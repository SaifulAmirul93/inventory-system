Hi!
Thanks for purchasing Invento

To install the system and start using it, please read the documentation included.
You can read it by double-clicking the following file inside the zip:

Documentation/index.html

If you have any questions, contact me at one of the following email addresses:
 - support@sglancer.com
 - tecnovirtu@gmail.com